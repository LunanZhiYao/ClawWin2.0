#!/usr/bin/env node

/**
 * 安装阿里云 OpenSearch 插件到 OpenClaw
 * 
 * 使用方法：
 *   node install-plugin.js
 */

const fs = require('fs')
const path = require('path')
const os = require('os')

const PLUGIN_NAME = 'aliyun-opensearch-plugin'
const PLUGIN_DIR = path.join(__dirname)

// 可能的 OpenClaw 插件目录
const POSSIBLE_PLUGIN_DIRS = [
  // 用户目录
  path.join(os.homedir(), '.openclaw', 'extensions'),
  // bundled 目录（开发环境）
  path.join(__dirname, '..', 'bundled', 'openclaw', 'extensions'),
  // bundled-cn 目录
  path.join(__dirname, '..', 'bundled', 'openclaw-cn', 'extensions'),
]

function copyDirSync(src, dest) {
  fs.mkdirSync(dest, { recursive: true })
  const entries = fs.readdirSync(src, { withFileTypes: true })
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name)
    const destPath = path.join(dest, entry.name)
    if (entry.isDirectory()) {
      copyDirSync(srcPath, destPath)
    } else {
      fs.copyFileSync(srcPath, destPath)
    }
  }
}

function installPlugin() {
  console.log('=== 安装阿里云 OpenSearch 插件 ===\n')
  
  // 检查插件目录是否存在
  if (!fs.existsSync(PLUGIN_DIR)) {
    console.error(`错误: 插件目录不存在: ${PLUGIN_DIR}`)
    process.exit(1)
  }
  
  // 检查必需文件
  const requiredFiles = ['openclaw.plugin.json', 'index.ts', 'package.json']
  for (const file of requiredFiles) {
    const filePath = path.join(PLUGIN_DIR, file)
    if (!fs.existsSync(filePath)) {
      console.error(`错误: 缺少必需文件: ${file}`)
      process.exit(1)
    }
  }
  
  // 查找可用的插件目录
  let installed = false
  for (const extensionsDir of POSSIBLE_PLUGIN_DIRS) {
    if (!fs.existsSync(extensionsDir)) {
      console.log(`创建目录: ${extensionsDir}`)
      fs.mkdirSync(extensionsDir, { recursive: true })
    }
    
    const targetDir = path.join(extensionsDir, PLUGIN_NAME)
    
    try {
      // 如果已存在，先删除
      if (fs.existsSync(targetDir)) {
        console.log(`删除旧版本: ${targetDir}`)
        fs.rmSync(targetDir, { recursive: true, force: true })
      }
      
      // 复制插件
      console.log(`安装插件到: ${targetDir}`)
      copyDirSync(PLUGIN_DIR, targetDir)
      
      console.log(`✅ 插件已安装到: ${targetDir}`)
      installed = true
    } catch (err) {
      console.error(`安装失败: ${targetDir}`, err.message)
    }
  }
  
  if (installed) {
    console.log('\n✅ 安装成功！')
    console.log('\n下一步：')
    console.log('1. 配置环境变量（在 ~/.openclaw/.env 或项目根目录的 .env 文件中）：')
    console.log('   ALIYUN_OPENSEARCH_API_KEY=your_api_key_here')
    console.log('   ALIYUN_OPENSEARCH_HOST=http://opensearch.cn-shanghai.aliyuncs.com')
    console.log('2. 重启 OpenClaw Gateway')
    console.log('3. 在聊天中使用：帮我搜索最新的 AI 技术趋势')
  } else {
    console.error('\n❌ 安装失败，请手动复制插件目录到 OpenClaw 的 extensions 目录')
    process.exit(1)
  }
}

installPlugin()
