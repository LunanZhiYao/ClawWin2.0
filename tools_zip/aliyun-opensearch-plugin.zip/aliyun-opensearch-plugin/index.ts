import type { OpenClawPluginApi, AnyAgentTool } from '../../src/plugins/types.js'

interface AliyunOpenSearchConfig {
  apiKey?: string
  host?: string
  workspace?: string
  serviceId?: string
  queryRewrite?: boolean
  contentType?: 'snippet' | 'summary'
  topK?: number
}

interface SearchHistoryItem {
  role: 'system' | 'user' | 'assistant'
  content: string
}

interface SearchResult {
  title: string
  link: string
  snippet: string
  content?: string
  position: number
}

interface AliyunSearchResponse {
  result?: {
    search_result?: SearchResult[]
  }
  usage?: {
    search_count?: number
    rewrite_model?: {
      input_tokens?: number
      output_tokens?: number
      total_tokens?: number
    }
    filter_model?: {
      input_tokens?: number
      output_tokens?: number
      total_tokens?: number
    }
  }
}

function createAliyunSearchTool(config: AliyunOpenSearchConfig): AnyAgentTool {
  return {
    name: 'aliyun_search',
    description: 
      '使用阿里云 OpenSearch 进行实时网络搜索，获取最新的网页信息和搜索结果。' +
      '支持智能查询重写和多轮对话上下文。' +
      '适用于需要获取实时信息、新闻、天气、技术文档等场景。',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '搜索查询词，例如："最新 AI 技术发展趋势"、"北京今日天气"',
        },
        top_k: {
          type: 'number',
          description: '返回结果数量（1-10），默认为 5',
          default: config.topK || 5,
        },
        query_rewrite: {
          type: 'boolean',
          description: '是否启用 LLM 对查询词进行智能重写优化，默认为 true',
          default: config.queryRewrite !== false,
        },
        content_type: {
          type: 'string',
          enum: ['snippet', 'summary'],
          description: 
            '搜索结果内容类型。snippet: 网页内容的简短描述（速度快）；' +
            'summary: 网页内容的文本摘要（内容更详细，耗时较长）',
          default: config.contentType || 'snippet',
        },
        history: {
          type: 'array',
          description: 
            '用户与模型的对话历史，用于多轮对话搜索。' +
            '格式: [{"role": "user/assistant", "content": "内容"}]',
          items: {
            type: 'object',
            properties: {
              role: {
                type: 'string',
                enum: ['system', 'user', 'assistant'],
              },
              content: {
                type: 'string',
              },
            },
            required: ['role', 'content'],
          },
        },
      },
      required: ['query'],
    },
    execute: async (_callId: string, params: any) => {
      console.log('[Aliyun OpenSearch] 原始 params:', JSON.stringify(params, null, 2))
      console.log('[Aliyun OpenSearch] params 类型:', typeof params)

      const apiKey = config.apiKey
      const host = config.host || 'http://opensearch.cn-shanghai.aliyuncs.com'
      const workspace = config.workspace || 'default'
      const serviceId = config.serviceId || 'ops-web-search-001'

      if (!apiKey) {
        throw new Error(
          '阿里云 OpenSearch API Key 未配置。' +
          '请在插件配置中指定 apiKey。'
        )
      }

      const url = `${host}/v3/openapi/workspaces/${workspace}/web-search/${serviceId}`

      const query = params.query
      const requestBody: Record<string, any> = {
        query: query,
        query_rewrite: params.query_rewrite !== false,
        top_k: Math.min(Math.max(params.top_k || 5, 1), 10),
        content_type: params.content_type || 'summary',
        history: params.history && Array.isArray(params.history) ? params.history : [],
      }

      console.log('[Aliyun OpenSearch] 请求参数:', JSON.stringify(requestBody, null, 2))
      console.log('[Aliyun OpenSearch] query 值:', query, '类型:', typeof query)

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify(requestBody),
        })
        
        if (!response.ok) {
          const errorText = await response.text()
          let errorMessage = `搜索请求失败: ${response.status}`
          
          try {
            const errorJson = JSON.parse(errorText)
            if (errorJson.message || errorJson.error) {
              errorMessage = `${errorMessage} - ${errorJson.message || errorJson.error}`
            }
          } catch {
            if (errorText) {
              errorMessage = `${errorMessage} - ${errorText}`
            }
          }
          
          if (response.status === 401) {
            errorMessage = 'API Key 无效或已过期，请检查配置'
          } else if (response.status === 403) {
            errorMessage = '权限不足或 QPS 超限，请检查 API Key 权限或联系技术支持'
          } else if (response.status === 429) {
            errorMessage = '请求频率超限（默认 QPS 限制为 3），请稍后重试'
          }
          
          throw new Error(errorMessage)
        }
        
        const data: AliyunSearchResponse = await response.json()
        const searchResults = data.result?.search_result || []
        
         if (searchResults.length === 0) {
          return {
            content: [{ type: 'text', text: '未找到相关搜索结果，建议尝试不同的搜索词。' }],
          }
        }

        const formattedResults = searchResults
          .map((item, index) => {
            let result = `### ${index + 1}. ${item.title}\n`
            result += `${item.snippet}\n`
            result += `[查看详情](${item.link})`
            return result
          })
          .join('\n\n')

        let usageInfo = ''
        if (data.usage) {
          const parts: string[] = []
          if (data.usage.search_count) {
            parts.push(`搜索次数: ${data.usage.search_count}`)
          }
          if (data.usage.rewrite_model?.total_tokens) {
            parts.push(`查询重写 tokens: ${data.usage.rewrite_model.total_tokens}`)
          }
          if (parts.length > 0) {
            usageInfo = `\n\n---\n*${parts.join(' | ')}*`
          }
        }

        return {
          content: [{ type: 'text', text: `## 搜索结果（共 ${searchResults.length} 条）\n\n${formattedResults}${usageInfo}` }],
        }
      } catch (error) {
        if (error instanceof Error) {
          throw error
        }
        throw new Error(`阿里云搜索失败: ${String(error)}`)
      }
    },
  }
}

const aliyunOpenSearchPlugin = {
  id: 'aliyun-opensearch',
  name: '阿里云 OpenSearch',
  description: '阿里云 OpenSearch 联网搜索插件，提供实时网络搜索能力，支持智能查询重写和多轮对话上下文',
  
  configSchema: {
    type: 'object',
    additionalProperties: false,
    properties: {
      apiKey: {
        type: 'string',
        description: '阿里云 OpenSearch API Key（必填）',
      },
      host: {
        type: 'string',
        description: 'API 服务地址，根据您的阿里云区域选择',
        default: 'http://opensearch.cn-shanghai.aliyuncs.com',
        examples: [
          'http://opensearch.aliyuncs.com',
          'http://opensearch.cn-shanghai.aliyuncs.com',
          'http://opensearch.cn-beijing.aliyuncs.com',
          'http://opensearch.cn-shenzhen.aliyuncs.com',
        ],
      },
      workspace: {
        type: 'string',
        description: '工作空间名称',
        default: 'default',
      },
      serviceId: {
        type: 'string',
        description: '服务ID',
        default: 'ops-web-search-001',
      },
      queryRewrite: {
        type: 'boolean',
        description: '是否默认启用查询重写',
        default: true,
      },
      contentType: {
        type: 'string',
        enum: ['snippet', 'summary'],
        description: '默认内容类型',
        default: 'summary',
      },
      topK: {
        type: 'number',
        description: '默认返回结果数量（1-10）',
        default: 5,
        minimum: 1,
        maximum: 10,
      },
    },
  },
  
  register(api: OpenClawPluginApi) {
    const pluginConfig = api.pluginConfig as AliyunOpenSearchConfig | undefined
    api.registerTool(createAliyunSearchTool(pluginConfig || {}))
    api.logger.info('阿里云 OpenSearch 搜索工具已注册')
  },
}

export default aliyunOpenSearchPlugin
